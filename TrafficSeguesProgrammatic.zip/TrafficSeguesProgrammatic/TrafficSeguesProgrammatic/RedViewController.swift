//
//  ViewController.swift
//  TrafficSeguesProgrammatic
//
//  Created by Derrick Park on 2020-12-11.
//

import UIKit

// Access modifiers
// ------- library ---------
// * open
// * public
// --------- App -----------
// * default (same mudule (app))
// * fileprivate (same file)
// * private (scope)
class RedViewController: UIViewController {
  
  private let goButton: UIButton = {
    let btn = UIButton(type: .system)
    btn.setTitle("Go Next", for: .normal)
    btn.translatesAutoresizingMaskIntoConstraints = false
    return btn
  }()
  
  override func viewDidLoad() {
    super.viewDidLoad()
    // set title navigation item title
    title = "Red"
    navigationController?.navigationBar.prefersLargeTitles = true
    view.backgroundColor = .red
    view.addSubview(goButton)
    goButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
    goButton.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    goButton.addTarget(self, action: #selector(goButtonTapped(_:)), for: .touchUpInside)
  }
  
  @objc func goButtonTapped(_ sender: UIButton) {
    let yellowVC = YellowViewController()
    navigationController?.pushViewController(yellowVC, animated: true)
  }
}
