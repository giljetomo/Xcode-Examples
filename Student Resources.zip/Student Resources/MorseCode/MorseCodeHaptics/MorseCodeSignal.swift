
import Foundation

enum MorseCodeSignal: String {
    case short = "."
    case long = "-"
}
