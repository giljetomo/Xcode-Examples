
import UIKit

struct StoreCategory: Hashable {
    let name: String
    let color = UIColor.random
}
