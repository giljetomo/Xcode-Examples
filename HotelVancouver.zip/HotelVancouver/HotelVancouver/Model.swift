//
//  Model.swift
//  HotelVancouver
//
//  Created by Derrick Park on 2021-01-11.
//

import Foundation

struct Registration {
  var checkInDate: Date
  var checkOutDate: Date
}
