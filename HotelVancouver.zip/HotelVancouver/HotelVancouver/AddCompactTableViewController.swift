//
//  AddCompactTableViewController.swift
//  HotelVancouver
//
//  Created by Derrick Park on 2021-01-11.
//

import UIKit

class AddCompactTableViewController: UITableViewController {
  let checkInLabelCell: DateCompactLabelTableViewCell = {
    let cell = DateCompactLabelTableViewCell()
    cell.label.text = "Check-In Date"
    let midnightToday = Calendar.current.startOfDay(for: Date()) // midnight
    cell.datePicker.minimumDate = midnightToday
    cell.datePicker.date = midnightToday
    return cell
  }()

  lazy var checkOutLabelCell: DateCompactLabelTableViewCell = {
    let cell = DateCompactLabelTableViewCell()
    cell.label.text = "Check-Out Date"
    cell.datePicker.minimumDate = Calendar.current.date(byAdding: .day, value: 1, to: checkInLabelCell.datePicker.date)
    return cell
  }()
  
  private let checkInLabelCellIndexPath = IndexPath(row: 0, section: 0)
  private let checkOutLabelCellIndexPath = IndexPath(row: 1, section: 0)
  private let dateFormatter: DateFormatter = {
    let df = DateFormatter()
    df.dateStyle = .medium
    return df
  }()
  
  fileprivate func updateDatePickers() {
    checkOutLabelCell.datePicker.minimumDate = Calendar.current.date(byAdding: .day, value: 1, to: checkInLabelCell.datePicker.date)
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    checkInLabelCell.datePicker.addTarget(self, action: #selector(dateValueChanged(_:)), for: .valueChanged)
    checkOutLabelCell.datePicker.addTarget(self, action: #selector(dateValueChanged(_:)), for: .valueChanged)
  }
  
  @objc func dateValueChanged(_ sender: UIDatePicker) {
    updateDatePickers()
  }
  
  // MARK: - Table view data source
  override func numberOfSections(in tableView: UITableView) -> Int {
    return 1
  }
  
  override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return 2
  }
  
  override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    switch indexPath {
    case checkInLabelCellIndexPath:
      return checkInLabelCell
    case checkOutLabelCellIndexPath:
      return checkOutLabelCell
    default:
      return UITableViewCell()
    }
  }
}
