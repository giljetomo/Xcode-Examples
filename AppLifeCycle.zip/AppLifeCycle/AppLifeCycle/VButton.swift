//
//  VButton.swift
//  AppLifeCycle
//
//  Created by Derrick Park on 2020-12-17.
//

import UIKit

class VButton: UIButton {
  
  override init(frame: CGRect) {
    super.init(frame: frame)
  }
  
  init(labelText: String, cornerRadius: CGFloat) {
    self.init()
    backgroundColor = .red
    translatesAutoresizingMaskIntoConstraints = false
    setTitle(labelText, for: .normal)
    layer.cornerRadius = cornerRadius
    clipsToBounds = true
  }
  
  required init?(coder: NSCoder) {
    fatalError("VButton is not supposed to be instantiated from the storyboard")
  }
}
