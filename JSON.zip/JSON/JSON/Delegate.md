## Tech Interview
- Algorithms & Data Structures
- OOP: MVC, Singleton, Adapter, Delegate, MVVM, Factory, ...
- "System Design (OOP design patterns, Architecture)"

## Design Pattern - solution to a well-known (existing) problem OOP
###  1. MVC (Model - View - Controller)
###  2. Singleton 
##  3. "Delegate Pattern"
##  Many more...
### "Boss -> Accountant"





