//
//  ColorTheme.swift
//  SushiLover
//
//  Created by Derrick Park on 5/21/20.
//  Copyright © 2020 Derrick Park. All rights reserved.
//

import UIKit

extension UIColor {
  static let mainRed = UIColor(rgb: 0xff6961)
}
