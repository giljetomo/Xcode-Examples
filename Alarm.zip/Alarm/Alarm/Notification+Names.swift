//
//  Notification+Names.swift
//  Alarm
//
//  Created by Derrick Park on 2021-02-10.
//  Copyright © 2021 AppDev Training. All rights reserved.
//

import Foundation

extension Notification.Name {
  static let alarmUpdated = Notification.Name("alarmUpdated")
}
